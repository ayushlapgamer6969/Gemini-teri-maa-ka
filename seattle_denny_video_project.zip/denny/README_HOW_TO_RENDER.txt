HOW TO MAKE THE VIDEO (Windows PC)
1. Install Node.js (LTS) from nodejs.org. Needs internet and a PC with a working graphics card.
2. Unzip this whole folder (do not run from inside the zip).
3. Double-click test_render.bat first. It makes a 1-second test (out\test.mp4).
4. Then double-click render.bat. When it says DONE, your video is final.mp4 in this folder.
First run downloads packages and a browser, so it takes longer.
Laptop: Windows Settings > System > Display > Graphics > set the browser used by Remotion to High performance.
If anything fails, send me the red error text from the black window.
