@echo off
cd /d "%~dp0"
echo === Seattle Denny Hill video: full render ===
where node >nul 2>nul || (echo Node.js is not installed. Install the LTS version from nodejs.org, then double-click this file again. & pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed. Check your internet and try again. & pause & exit /b 1)
if not exist out mkdir out
call npx remotion render src/index.js Denny out\full_silent.mp4 --gl=angle --concurrency=4 --image-format=jpeg --jpeg-quality=92 --crf=17
if errorlevel 1 (echo Render failed. Send me the red error text. & pause & exit /b 1)
call npx remotion ffmpeg -y -i out\full_silent.mp4 -i audio_mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest final.mp4
echo.
echo DONE. Your video is final.mp4 in this folder.
pause
