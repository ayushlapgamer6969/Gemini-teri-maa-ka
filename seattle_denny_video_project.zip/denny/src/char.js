import React, {useMemo} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {h, INK, rng, clamp, planeGeo} from './kit.js';

const PAL = {
  navy: {skin: '#f2e2cf', coat: '#3f5d7a', coat2: '#d8c9a6', hair: '#4a3328', hat: '#2b2b33'},
  brown: {skin: '#efdcc6', coat: '#8a5a3a', coat2: '#d9b27a', hair: '#2f2a28', hat: '#4a3a30'},
  green: {skin: '#f0dfca', coat: '#5d7a4a', coat2: '#d8d09a', hair: '#6a4a2e', hat: '#3a4a2e'},
  gray: {skin: '#f1e1cc', coat: '#6a6a74', coat2: '#d6d0c0', hair: '#3b3b3b', hat: '#2a2a2a'},
  red: {skin: '#f0dcc8', coat: '#8f3f3a', coat2: '#e0c6a0', hair: '#3a2820', hat: '#2a1f1f'},
};
const _t = {};

function wobbleEllipse(ctx, cx, cy, rx, ry, r, fill) {
  const pts = [];
  const n = 28;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const k = 1 + (r() - 0.5) * 0.05;
    pts.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
  }
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
  ctx.closePath();
  ctx.lineJoin = 'round';
  ctx.lineWidth = 7 + r() * 3;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = fill;
  ctx.fill();
}
function limb(ctx, x1, y1, x2, y2, r) {
  ctx.lineCap = 'round';
  ctx.strokeStyle = INK;
  ctx.lineWidth = 13 + r() * 2;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.strokeStyle = '#4a3a3a';
  ctx.lineWidth = 6;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
}

export function charTex({pal = 'navy', hat = 'none', glasses = false, tie = '#a63a35', folded = false, seed = 3}) {
  const key = [pal, hat, glasses, tie, folded, seed].join('|');
  if (_t[key]) return _t[key];
  const P = PAL[pal];
  const r = rng(seed * 77 + 5);
  const c = document.createElement('canvas');
  c.width = 300; c.height = 600;
  const ctx = c.getContext('2d');
  // legs
  limb(ctx, 135, 385, 122, 545, r);
  limb(ctx, 165, 385, 178, 545, r);
  wobbleEllipse(ctx, 112, 556, 24, 11, r, INK);
  wobbleEllipse(ctx, 188, 556, 24, 11, r, INK);
  // arms
  if (folded) {
    limb(ctx, 112, 225, 175, 300, r);
    limb(ctx, 188, 225, 125, 300, r);
  } else {
    limb(ctx, 112, 225, 78, 345, r);
    limb(ctx, 188, 225, 222, 345, r);
    wobbleEllipse(ctx, 76, 352, 13, 13, r, INK);
    wobbleEllipse(ctx, 224, 352, 13, 13, r, INK);
  }
  // pear-shaped two-tone torso
  ctx.beginPath();
  ctx.moveTo(122, 195);
  ctx.bezierCurveTo(95, 240, 85, 330, 118, 392);
  ctx.lineTo(182, 392);
  ctx.bezierCurveTo(215, 330, 205, 240, 178, 195);
  ctx.closePath();
  ctx.lineJoin = 'round'; ctx.lineWidth = 8; ctx.strokeStyle = INK; ctx.stroke();
  ctx.fillStyle = P.coat; ctx.fill();
  ctx.save(); ctx.clip();
  ctx.fillStyle = P.coat2; ctx.fillRect(80, 320, 150, 90);
  ctx.restore();
  ctx.fillStyle = '#e8d3a2'; ctx.fillRect(134, 335, 30, 22); // pocket patch
  ctx.strokeStyle = INK; ctx.lineWidth = 3; ctx.strokeRect(134, 335, 30, 22);
  // collar + tie
  ctx.fillStyle = '#fbf6ea';
  ctx.beginPath(); ctx.moveTo(150, 205); ctx.lineTo(122, 190); ctx.lineTo(128, 222); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(150, 205); ctx.lineTo(178, 190); ctx.lineTo(172, 222); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = INK; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(122, 190); ctx.lineTo(150, 205); ctx.lineTo(178, 190); ctx.stroke();
  ctx.fillStyle = tie;
  ctx.beginPath(); ctx.moveTo(150, 205); ctx.lineTo(141, 232); ctx.lineTo(150, 290); ctx.lineTo(159, 232); ctx.closePath(); ctx.fill();
  ctx.stroke();
  // big round pale head
  wobbleEllipse(ctx, 150, 112, 84, 82, r, P.skin);
  // hair fringe
  if (hat !== 'cap' && hat !== 'tophat' && hat !== 'bowler') {
    ctx.fillStyle = P.hair;
    ctx.beginPath(); ctx.moveTo(70, 100); ctx.quadraticCurveTo(150, 10, 230, 100); ctx.quadraticCurveTo(190, 62, 150, 74); ctx.quadraticCurveTo(110, 62, 70, 100); ctx.fill();
  }
  // half-lidded eyes
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.ellipse(118, 120, 14, 10, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(182, 120, 14, 10, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(118, 123, 6, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(182, 123, 6, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = P.skin;
  ctx.fillRect(100, 106, 40, 9); ctx.fillRect(160, 106, 40, 9); // lids
  ctx.strokeStyle = INK; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(102, 115); ctx.lineTo(134, 115); ctx.moveTo(166, 115); ctx.lineTo(198, 115); ctx.stroke();
  // tiny smile
  ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(150, 148, 16, 0.25 * Math.PI, 0.75 * Math.PI); ctx.stroke();
  if (glasses) {
    ctx.lineWidth = 5;
    ctx.beginPath(); ctx.arc(118, 121, 22, 0, Math.PI * 2); ctx.moveTo(204, 121); ctx.arc(182, 121, 22, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(140, 119); ctx.lineTo(160, 119); ctx.stroke();
  }
  // hats
  const H = P.hat;
  const hatShape = (draw) => { ctx.fillStyle = H; draw(); ctx.lineWidth = 6; ctx.strokeStyle = INK; ctx.stroke(); };
  if (hat === 'tophat') {
    hatShape(() => { ctx.beginPath(); ctx.rect(96, -2, 108, 66); });
    ctx.fill();
    hatShape(() => { ctx.beginPath(); ctx.ellipse(150, 66, 96, 14, 0, 0, Math.PI * 2); });
    ctx.fill();
  } else if (hat === 'bowler') {
    hatShape(() => { ctx.beginPath(); ctx.arc(150, 62, 66, Math.PI, 0); ctx.closePath(); });
    ctx.fill();
    hatShape(() => { ctx.beginPath(); ctx.ellipse(150, 64, 92, 12, 0, 0, Math.PI * 2); });
    ctx.fill();
  } else if (hat === 'cap') {
    hatShape(() => { ctx.beginPath(); ctx.arc(150, 70, 70, Math.PI, 0); ctx.closePath(); });
    ctx.fill();
    hatShape(() => { ctx.beginPath(); ctx.ellipse(205, 72, 50, 10, 0.05, 0, Math.PI * 2); });
    ctx.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  _t[key] = t;
  return t;
}

// flat 2D character standing in the 3D world. height in metres.
export function Character({pos = [0, 0, 0], hgt = 3.4, frame = 0, phase = 0, ...variant}) {
  const cam = useThree((s) => s.camera);
  const map = charTex(variant);
  const yaw = clamp(Math.atan2(cam.position.x - pos[0], cam.position.z - pos[2]), -0.7, 0.7);
  const bob = Math.sin((frame + phase * 17) * 0.09) * 0.04;
  const sway = Math.sin((frame + phase * 23) * 0.06) * 0.025;
  const mat = useMemo(() => new THREE.MeshBasicMaterial({map, transparent: true, alphaTest: 0.35, side: THREE.DoubleSide}), [map]);
  const blob = useMemo(() => new THREE.MeshBasicMaterial({color: '#2a1a18', transparent: true, opacity: 0.28}), []);
  const w = hgt / 2;
  return h('group', {position: pos},
    h('mesh', {geometry: blobGeo(), material: blob, rotation: [-Math.PI / 2, 0, 0], position: [0, 0.04, 0], scale: [w * 0.55, w * 0.22, 1]}),
    h('group', {rotation: [0, yaw, sway]},
      h('mesh', {geometry: planeGeo(w, hgt), material: mat, position: [0, hgt / 2 + bob, 0]})));
}
let _b = null;
function blobGeo() {
  if (!_b) _b = new THREE.CircleGeometry(1, 20);
  return _b;
}
