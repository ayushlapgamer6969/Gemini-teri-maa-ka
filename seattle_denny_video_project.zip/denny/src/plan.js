import {CUTS, DURATION, X, wordTime} from './times.js';

const k = (at, p, l) => ({at, p, l});
const E = [...CUTS, DURATION];

// Camera plan: per shot, keys reached on named words. Last key of a shot = first key of the next one inside a location.
export const KEYS = [
  // 1 hill overview: crane down toward the hill
  [k(E[0], [-22, 30, 52], [0, 9, 0]), k(E[1], [-6, 17, 34], [2, 8, -2])],
  // 2 office: push to the engineer, then to the map
  [k(E[1], [X.office + 1, 3.6, 9], [X.office - 1, 2.6, 0]), k(wordTime('s2', 8), [X.office - 1.5, 3.3, 3.8], [X.office - 1.4, 3.8, -4.6]), k(E[2], [X.office - 2.5, 3.2, 2.8], [X.office - 2, 3.9, -4.6])],
  // 3 hydraulic giants: sideways track across the cut
  [k(E[2], [X.cut - 18, 7, 24], [X.cut - 4, 7, 0]), k(14.6, [X.cut, 8, 24], [X.cut + 2, 7, 0]), k(E[3], [X.cut + 18, 9, 22], [X.cut + 6, 6, 0])],
  // 4 hotel on the summit: push in
  [k(E[3], [X.hotel - 14, 19.5, 26], [X.hotel, 18, 0]), k(E[4], [X.hotel - 4, 18.8, 13], [X.hotel - 1, 19, 0])],
  // 5 the hill is cut away: crane down to street level, looking up at the perched hotel
  [k(E[4], [X.hotel - 4, 18.8, 13], [X.hotel - 1, 19, 0]), k(wordTime('s5', 10), [X.hotel + 8, 11, 24], [X.hotel, 14, 0]), k(E[5], [X.hotel + 10, 3.2, 27], [X.hotel, 15, 0])],
  // 6 owners and the bill: track left to right
  [k(E[5], [X.owners - 4.5, 3, 7], [X.owners - 2.5, 2.4, -1]), k(E[6], [X.owners + 3.5, 3.1, 7.2], [X.owners + 1.2, 2.4, -1])],
  // 7 timber cribbing: wide, stacks, lowering, rest
  [k(E[6], [X.cribs - 12, 6, 17], [X.cribs, 4, 0]), k(wordTime('s7b', 3), [X.cribs - 4, 3, 10], [X.cribs - 1.5, 2.2, 0]), k(wordTime('s7b', 10), [X.cribs + 6, 2.8, 10.5], [X.cribs + 1, 3, 0]), k(E[7], [X.cribs + 6.5, 2.4, 9.8], [X.cribs + 1, 3.4, 0])],
  // 8 Blanchard cut: drop into the trench and look down the street
  [k(E[7], [X.blanchard - 22, 26, 12], [X.blanchard, 6, 0]), k(E[8], [X.blanchard - 18, 5, 0.5], [X.blanchard + 4, 4, 0])],
  // 9 flat city: sideways track along the street
  [k(E[8], [X.city - 14, 4.8, 14], [X.city - 8, 3.6, 0]), k(E[9], [X.city + 14, 5.4, 14], [X.city + 8, 3.8, 0])],
  // 10 pull back and up to show the bay
  [k(E[9], [X.city + 14, 5.4, 14], [X.city + 8, 3.8, 0]), k(DURATION, [X.city + 2, 16, 40], [X.city, 2, -8])],
];
export const LOC = ['hill', 'office', 'cut', 'hotel', 'hotel', 'owners', 'cribs', 'blanchard', 'city', 'city'];
