import React from 'react';
import {Composition} from 'remotion';
import {Full} from './Full.js';
import {FPS, DURATION} from './times.js';

export const Root = () =>
  React.createElement(Composition, {
    id: 'Denny',
    component: Full,
    durationInFrames: Math.ceil(DURATION * FPS),
    fps: FPS,
    width: 720,
    height: 1280,
  });
