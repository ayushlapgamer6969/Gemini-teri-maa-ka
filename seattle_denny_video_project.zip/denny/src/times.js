// Real sentence timing measured from the uploaded voice-over (pauses found with silence detection).
export const FPS = 30;
export const DURATION = 54.75; // seconds, length of the voice-over file

export const SENT = {
  s1: {start: 0.0, end: 5.11, words: 14},
  s2: {start: 5.71, end: 11.33, words: 15},
  s3: {start: 11.88, end: 17.375, words: 15},
  s4: {start: 17.98, end: 21.72, words: 13},
  s5: {start: 22.31, end: 27.7, words: 17},
  s6: {start: 28.22, end: 31.46, words: 13},
  s7a: {start: 32.11, end: 34.53, words: 7},
  s7b: {start: 35.11, end: 39.74, words: 13},
  s8: {start: 40.26, end: 44.0, words: 14},
  s9: {start: 44.55, end: 50.22, words: 16},
  s10a: {start: 50.76, end: 52.69, words: 6},
  s10b: {start: 53.18, end: 54.44, words: 5},
};

// time at which word number `w` (0-based) of a sentence starts, by proportion
export const wordTime = (id, w) => {
  const s = SENT[id];
  return s.start + (w / s.words) * (s.end - s.start);
};

// One array of cuts. A cut falls in the pause after a sentence ends.
export const CUTS = [0, 5.4, 11.6, 17.65, 22.0, 27.95, 31.8, 40.0, 44.3, 50.5];
// shots that start a NEW location get a 0.4 s dip to cream (shots 5 and 10 continue the previous place)
export const DIPS = [5.4, 11.6, 17.65, 27.95, 31.8, 40.0, 44.3];

export const X = {hill: 0, office: 40, cut: 80, hotel: 120, owners: 200, cribs: 240, blanchard: 280, city: 320};

export const shotIndex = (t) => {
  let i = 0;
  for (let k = 0; k < CUTS.length; k++) if (t >= CUTS[k]) i = k;
  return i;
};
