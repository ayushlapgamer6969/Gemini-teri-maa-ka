import React, {useMemo} from 'react';
import * as THREE from 'three';

export const INK = '#351f22';
export const h = React.createElement;
export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
export const ease = (t) => {
  t = clamp(t);
  return t * t * (3 - 2 * t);
};
export const backOut = (t) => {
  t = clamp(t);
  const c = 1.7;
  return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2);
};
export function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

// 3-band toon gradient
let _grad = null;
export function gradient() {
  if (!_grad) {
    _grad = new THREE.DataTexture(Uint8Array.from([95, 175, 255]), 3, 1, THREE.RedFormat);
    _grad.minFilter = THREE.NearestFilter;
    _grad.magFilter = THREE.NearestFilter;
    _grad.needsUpdate = true;
  }
  return _grad;
}
const _mats = {};
export function toon(color, opts) {
  const key = color + (opts ? JSON.stringify(opts) : '');
  if (!_mats[key]) {
    _mats[key] = new THREE.MeshToonMaterial({color, gradientMap: gradient(), ...(opts || {})});
  }
  return _mats[key];
}
export const inkMat = new THREE.MeshBasicMaterial({color: INK, side: THREE.BackSide});
export const edgeMat = new THREE.LineBasicMaterial({color: INK});

// ---- painted textures (flat colours with wear) ----
const _tex = {};
function canvasTex(key, w, hgt, draw) {
  if (!_tex[key]) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = hgt;
    draw(c.getContext('2d'), w, hgt);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4;
    _tex[key] = t;
  }
  return _tex[key];
}
function wear(ctx, w, hgt, seed, n, dark) {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = dark ? 'rgba(53,31,34,' + (0.04 + r() * 0.07) + ')' : 'rgba(255,245,220,' + (0.05 + r() * 0.08) + ')';
    const x = r() * w, y = r() * hgt;
    ctx.fillRect(x, y, 4 + r() * 28, 2 + r() * 10);
  }
}

// facade: wall colour with a grid of windows and an optional door
export function facadeTex({wall, win = '#3b4a58', trim = '#efe3c8', cols = 3, rows = 2, door = true, seed = 1, brick = false}) {
  const key = ['fac', wall, win, trim, cols, rows, door, seed, brick].join('|');
  return canvasTex(key, 256, 256, (ctx, w, hgt) => {
    ctx.fillStyle = wall;
    ctx.fillRect(0, 0, w, hgt);
    if (brick) {
      ctx.strokeStyle = 'rgba(53,31,34,0.18)';
      ctx.lineWidth = 1;
      for (let y = 0; y < hgt; y += 12) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        for (let x = (y / 12) % 2 ? 0 : 12; x < w; x += 24) {
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 12); ctx.stroke();
        }
      }
    }
    wear(ctx, w, hgt, seed, 40, true);
    wear(ctx, w, hgt, seed + 9, 14, false);
    const bandH = hgt / (rows + (door ? 0.9 : 0));
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cw = w / cols;
        const x = c * cw + cw * 0.22, y = r * bandH + bandH * 0.2;
        const ww = cw * 0.56, wh = bandH * 0.55;
        ctx.fillStyle = INK; ctx.fillRect(x - 4, y - 4, ww + 8, wh + 8);
        ctx.fillStyle = trim; ctx.fillRect(x - 2, y - 2, ww + 4, wh + 4);
        ctx.fillStyle = win; ctx.fillRect(x + 3, y + 3, ww - 6, wh - 6);
        ctx.fillStyle = trim; ctx.fillRect(x - 6, y + wh, ww + 12, 7); // sill
        ctx.fillStyle = INK; ctx.fillRect(x + ww / 2 - 1, y + 3, 2, wh - 6);
      }
    }
    if (door) {
      const dw = w * 0.2, dh = hgt * 0.28;
      ctx.fillStyle = INK; ctx.fillRect(w / 2 - dw / 2 - 4, hgt - dh - 4, dw + 8, dh + 4);
      ctx.fillStyle = '#8a5a3a'; ctx.fillRect(w / 2 - dw / 2, hgt - dh, dw, dh);
      ctx.fillStyle = '#6e4529'; ctx.fillRect(w / 2 - dw / 2 + 5, hgt - dh + 8, dw / 2 - 8, dh - 16);
      ctx.fillRect(w / 2 + 3, hgt - dh + 8, dw / 2 - 8, dh - 16);
    }
    ctx.strokeStyle = INK; ctx.lineWidth = 6; ctx.strokeRect(0, 0, w, hgt);
  });
}

// painted sign / board texture
export function signTex(lines, bg = '#efe3c8', fg = INK, opts = {}) {
  const key = ['sign', lines.join('/'), bg, fg, JSON.stringify(opts)].join('|');
  return canvasTex(key, 512, opts.tall ? 512 : 256, (ctx, w, hgt) => {
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, hgt);
    wear(ctx, w, hgt, 7 + lines.join('').length, 60, true);
    ctx.strokeStyle = fg; ctx.lineWidth = 10; ctx.strokeRect(14, 14, w - 28, hgt - 28);
    ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const n = lines.length;
    const size = Math.min(opts.size || 86, (hgt - 60) / n * 0.82, (w - 60) / Math.max(...lines.map((l) => l.length)) * 1.7);
    ctx.font = 'bold ' + size + 'px Georgia, "Times New Roman", serif';
    lines.forEach((l, i) => ctx.fillText(l, w / 2, hgt / 2 + (i - (n - 1) / 2) * size * 1.1));
  });
}

export function skyTex() {
  return canvasTex('sky', 16, 256, (ctx, w, hgt) => {
    const g = ctx.createLinearGradient(0, 0, 0, hgt);
    g.addColorStop(0, '#8fbfd6');
    g.addColorStop(0.55, '#cfe3e6');
    g.addColorStop(0.8, '#f3e6c8');
    g.addColorStop(1, '#efe0bd');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, hgt);
  });
}

// ---- model parts ----
export function Block({size, pos = [0, 0, 0], rot = [0, 0, 0], color = '#c9a97a', ink = true, map = null, shadow = true, t = 0.14, tint}) {
  const [w, hh, d] = size;
  const geo = useMemo(() => new THREE.BoxGeometry(w, hh, d), [w, hh, d]);
  const edges = useMemo(() => new THREE.EdgesGeometry(geo), [geo]);
  const mat = map ? toon('#ffffff', {map, _k: map.uuid}) : toon(color);
  return h('group', {position: pos, rotation: rot},
    h('mesh', {geometry: geo, material: mat, castShadow: shadow, receiveShadow: shadow}),
    ink ? h('mesh', {geometry: geo, material: inkMat, scale: [(w + t) / w, (hh + t) / hh, (d + t) / d]}) : null,
    ink ? h('lineSegments', {geometry: edges, material: edgeMat}) : null);
}

// box whose +z face carries a painted texture (windows etc.)
export function PaintedBlock({size, pos = [0, 0, 0], color, map, rot = [0, 0, 0]}) {
  const [w, hh, d] = size;
  return h('group', {position: pos, rotation: rot},
    h(Block, {size, color}),
    h('mesh', {position: [0, 0, d / 2 + 0.02], material: basicMat(map), geometry: planeGeo(w, hh)}));
}
const _bm = {};
export function basicMat(map) {
  if (!_bm[map.uuid]) _bm[map.uuid] = new THREE.MeshBasicMaterial({map});
  return _bm[map.uuid];
}
const _pg = {};
export function planeGeo(w, hh) {
  const k = w + 'x' + hh;
  if (!_pg[k]) _pg[k] = new THREE.PlaneGeometry(w, hh);
  return _pg[k];
}

export function Cyl({r = 0.5, r2, len = 1, pos = [0, 0, 0], rot = [0, 0, 0], color = '#8a8a8a', seg = 14, t = 0.12}) {
  const geo = useMemo(() => new THREE.CylinderGeometry(r2 === undefined ? r : r2, r, len, seg), [r, r2, len, seg]);
  return h('group', {position: pos, rotation: rot},
    h('mesh', {geometry: geo, material: toon(color), castShadow: true, receiveShadow: true}),
    h('mesh', {geometry: geo, material: inkMat, scale: [(r + t) / r, (len + t) / len, (r + t) / r]}));
}

// gable roof, ridge along z, base at y = 0
const roofGeo = new THREE.CylinderGeometry(1, 1, 1, 3);
export function Roof({w, d, hgt, color = '#8c4b3a', pos = [0, 0, 0]}) {
  const s = hgt / 1.5;
  return h('group', {position: pos},
    h('mesh', {geometry: roofGeo, material: toon(color), rotation: [-Math.PI / 2, 0, 0], scale: [w / 1.732, d, s], position: [0, s / 2, 0], castShadow: true}),
    h('mesh', {geometry: roofGeo, material: inkMat, rotation: [-Math.PI / 2, 0, 0], scale: [w / 1.732 + 0.1, d + 0.1, s + 0.1], position: [0, s / 2, 0]}));
}
const pyrGeo = new THREE.ConeGeometry(1, 1, 4);
export function Pyramid({w, hgt, color = '#8c4b3a', pos = [0, 0, 0]}) {
  return h('group', {position: pos, rotation: [0, Math.PI / 4, 0]},
    h('mesh', {geometry: pyrGeo, material: toon(color), scale: [w * 0.7071, hgt, w * 0.7071], position: [0, hgt / 2, 0], castShadow: true}),
    h('mesh', {geometry: pyrGeo, material: inkMat, scale: [w * 0.7071 + 0.12, hgt + 0.12, w * 0.7071 + 0.12], position: [0, hgt / 2, 0]}));
}

// painted board with text. appearAt: seconds when it pops in (time given by `t`)
export function Board({t = 99, appearAt = 0, size = [4, 1.6], pos = [0, 0, 0], rot = [0, 0, 0], lines, bg, fg, tall, fontSize, poles = 0}) {
  const k = backOut((t - appearAt) / 0.4);
  if (k <= 0.001) return null;
  const [w, hh] = size;
  const map = signTex(lines, bg, fg, {tall, size: fontSize});
  const mat = basicMat(map);
  return h('group', {position: pos, rotation: rot, scale: [k, k, k]},
    h(Block, {size: [w, hh, 0.25], color: '#7a5a3c'}),
    h('mesh', {geometry: planeGeo(w - 0.15, hh - 0.15), material: mat, position: [0, 0, 0.14]}),
    poles ? h(Block, {size: [0.22, poles, 0.22], pos: [-w / 2 + 0.2, -hh / 2 - poles / 2, 0], color: '#6a4a30'}) : null,
    poles ? h(Block, {size: [0.22, poles, 0.22], pos: [w / 2 - 0.2, -hh / 2 - poles / 2, 0], color: '#6a4a30'}) : null);
}

export function LampPost({pos = [0, 0, 0], hgt = 5}) {
  return h('group', {position: pos},
    h(Cyl, {r: 0.12, len: hgt, pos: [0, hgt / 2, 0], color: '#3d3a3a', seg: 8}),
    h(Block, {size: [0.5, 0.6, 0.5], pos: [0, hgt + 0.3, 0], color: '#f2d98a'}));
}
