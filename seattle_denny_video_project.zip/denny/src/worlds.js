import React from 'react';
import * as THREE from 'three';
import {h, rng, ease, clamp, Block, PaintedBlock, Cyl, Roof, Pyramid, Board, LampPost, facadeTex, signTex, basicMat, planeGeo, toon, INK} from './kit.js';
import {Terrain, heightAt} from './terrain.js';
import {Character} from './char.js';
import {X, wordTime} from './times.js';

const HILL = {cx: 0, cz: 0, H: 16, sig: 14, cut: 0, bay: true};
const WALLS = ['#d9b98a', '#c98f6a', '#a9bfa0', '#d8cfa5', '#b7a28c', '#c4a07a'];
const ROOFS = ['#8c4b3a', '#6a4a3a', '#7a5a4a', '#5a4a4a'];

function House({pos, w = 2.8, hgt = 2.2, d = 2.4, i = 0}) {
  const wall = WALLS[i % WALLS.length];
  const map = facadeTex({wall, cols: 2, rows: 1, door: true, seed: i + 3});
  return h('group', {position: pos},
    h(PaintedBlock, {size: [w, hgt, d], pos: [0, hgt / 2, 0], color: wall, map}),
    h(Roof, {w: w + 0.4, d: d + 0.3, hgt: 1.2, color: ROOFS[i % ROOFS.length], pos: [0, hgt, 0]}));
}
function Town({P, n = 22, seed = 5, maxR = 24}) {
  const r = rng(seed);
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = r() * Math.PI * 2, d = 4 + r() * (maxR - 4);
    const x = Math.cos(a) * d, z = Math.sin(a) * d;
    if (z < -15) continue;
    out.push(h(House, {key: i, i, pos: [x, heightAt(x, z, P) - 0.1, z]}));
  }
  return h('group', null, out);
}
function Downtown({x0 = 34}) {
  const r = rng(11);
  const out = [];
  for (let i = 0; i < 9; i++) {
    const x = x0 + (i % 3) * 5.2, z = -8 + Math.floor(i / 3) * 7;
    const hh = 4 + r() * 5, wall = WALLS[i % WALLS.length];
    const map = facadeTex({wall, cols: 3, rows: Math.round(hh / 1.6), door: true, seed: 20 + i, brick: i % 2 === 0});
    out.push(h(PaintedBlock, {key: i, size: [4.4, hh, 4.4], pos: [x, hh / 2 + 0.4, z], color: wall, map}));
  }
  return h('group', null, out);
}

// ---------- 1. hill overview ----------
export function WorldHill({t, frame}) {
  return h('group', null,
    h(Terrain, {P: HILL}),
    h(Town, {P: HILL}),
    h(Downtown, {}),
    h(Board, {t, appearAt: 1.0, size: [5, 1.5], pos: [-9, 17, 9], rot: [0, 0.3, 0], lines: ['DENNY HILL'], bg: '#efe3c8', fg: INK, poles: 3}));
}

// ---------- 2. engineer's office ----------
let _map = null;
function mapMat() {
  if (!_map) {
    const c = document.createElement('canvas');
    c.width = 512; c.height = 360;
    const x = c.getContext('2d');
    x.fillStyle = '#f1e4c2'; x.fillRect(0, 0, 512, 360);
    x.fillStyle = INK; x.font = 'bold 40px Georgia, serif'; x.textAlign = 'center'; x.fillText('DENNY HILL', 256, 52);
    let n = 0;
    for (let r = 0; r < 8; r++) for (let q = 0; q < 8; q++) {
      n++;
      if (n > 62) continue;
      x.fillStyle = (r + q) % 3 === 0 ? '#b98a52' : '#c9a876';
      x.fillRect(66 + q * 47, 72 + r * 34, 42, 29);
      x.strokeStyle = INK; x.lineWidth = 2; x.strokeRect(66 + q * 47, 72 + r * 34, 42, 29);
    }
    x.strokeStyle = INK; x.lineWidth = 8; x.strokeRect(8, 8, 496, 344);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    _map = basicMat(t);
  }
  return _map;
}
export function WorldOffice({t, frame}) {
  const x0 = X.office;
  return h('group', null,
    h(Block, {size: [18, 0.4, 13], pos: [x0 + 2, -0.2, 0], color: '#9a7a58'}),
    h(Block, {size: [18, 8.5, 0.5], pos: [x0 + 2, 4.05, -5.5], color: '#cdbf9f'}),
    h(Block, {size: [0.5, 8.5, 13], pos: [x0 - 7, 4.05, 0], color: '#c4b48f'}),
    h(Block, {size: [6.6, 4.8, 0.25], pos: [x0 - 1.8, 4.3, -5.1], color: '#6a4a30'}),
    h('mesh', {geometry: planeGeo(6.1, 4.3), material: mapMat(), position: [x0 - 1.8, 4.3, -4.96]}),
    h(Board, {t, appearAt: wordTime('s2', 2), size: [2.4, 0.9], pos: [x0 + 0.6, 3.1, -4.7], rot: [0, 0, -0.12], lines: ['62 BLOCKS'], bg: '#f3d9d0', fg: '#a63a35'}),
    h(Block, {size: [4.2, 1.5, 1.7], pos: [x0 + 4.6, 0.75, -2.6], color: '#7a5a3c'}),
    h(Board, {t, size: [2.2, 0.55], pos: [x0 + 4.6, 1.8, -1.7], lines: ['CITY ENGINEER'], bg: '#efe3c8', fg: INK, fontSize: 60}),
    h(Block, {size: [1.2, 0.2, 0.9], pos: [x0 + 3.4, 1.6, -2.6], color: '#fbf6ea'}),
    h(Character, {pos: [x0 + 3.2, 0, 0.5], frame, pal: 'navy', hat: 'bowler', glasses: true, seed: 2}));
}

// ---------- 3. giants cut the hill ----------
function Jet({from, to, frame, lift = 0.14}) {
  const N = 16, L = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
  const out = [];
  for (let i = 0; i < N; i++) {
    const s = (i / N + frame * 0.035) % 1;
    const p = [from[0] + (to[0] - from[0]) * s, from[1] + (to[1] - from[1]) * s + Math.sin(s * Math.PI) * L * lift, from[2] + (to[2] - from[2]) * s];
    out.push(h('mesh', {key: i, position: p, geometry: sph(), material: toon('#bfe6f2'), scale: 0.22 + 0.18 * s}));
  }
  return h('group', null, out);
}
let _s = null;
const sph = () => (_s = _s || new THREE.SphereGeometry(1, 8, 6));
function Giant({pos, aim, frame}) {
  const dx = aim[0] - pos[0], dy = aim[1] - pos[1], dz = aim[2] - pos[2];
  const yaw = Math.atan2(dx, dz), pitch = -Math.atan2(dy, Math.hypot(dx, dz));
  const e = new THREE.Euler(pitch, yaw, 0, 'YXZ');
  const mz = [0, 1.3, 0];
  return h('group', null,
    h(Block, {size: [1.8, 0.7, 1.8], pos: [pos[0], pos[1] + 0.35, pos[2]], color: '#6a4a30'}),
    h('group', {position: [pos[0], pos[1] + 1.3, pos[2]], rotation: e},
      h(Cyl, {r: 0.42, len: 3.2, pos: [0, 0, 1.6], rot: [Math.PI / 2, 0, 0], color: '#6e7f8a'}),
      h(Cyl, {r: 0.55, len: 0.5, pos: [0, 0, 0], rot: [Math.PI / 2, 0, 0], color: '#4e5f6a'})),
    h(Jet, {from: [pos[0] + Math.sin(yaw) * 3.2, pos[1] + 1.3 + Math.sin(-pitch) * 3.2, pos[2] + Math.cos(yaw) * 3.2], to: aim, frame}));
}
export function WorldCut({t, frame}) {
  const cut = ease((t - 11.9) / 5.3) * 0.62;
  const P = {...HILL, cut};
  const g = (x, z) => heightAt(x, z, P) + 0.1;
  const a1 = [-6, g(-6, 15), 15], a2 = [4, g(4, 16), 16];
  const aimY = 9 * (1 - cut * 0.7);
  return h('group', null,
    h(Terrain, {P}),
    h(Giant, {pos: a1, aim: [-4, aimY, 6], frame}),
    h(Giant, {pos: a2, aim: [6, aimY - 1, 6], frame: frame + 7}),
    h(Character, {pos: [-1, g(-1, 17), 17.5], frame, pal: 'gray', hat: 'cap', seed: 5, hgt: 3.2}),
    h('mesh', {geometry: disc(), material: toon('#8a6a4a'), rotation: [-Math.PI / 2, 0, 0], position: [0, 0.06, -34], scale: [4 + cut * 40, 4 + cut * 40, 1]}),
    h(Board, {t, appearAt: 12.4, size: [4.4, 1.3], pos: [-14, g(-14, 14) + 3.4, 14], rot: [0, 0.35, 0], lines: ['HYDRAULIC GIANTS'], bg: '#efe3c8', fg: INK, poles: 2.4, fontSize: 46}));
}
let _d = null;
const disc = () => (_d = _d || new THREE.CircleGeometry(1, 32));

// ---------- 4/5. the hotel on its pillar ----------
export function WorldHotel({t, frame}) {
  const cut = t < 22 ? 0 : ease((t - 22) / 4.4) * 0.97;
  const P = {...HILL, cut, pillar: {x: 0, z: 0, r0: 7.5, r1: 10}};
  const y = 16;
  const wall = '#e2d2a8';
  const map = facadeTex({wall, cols: 6, rows: 2, door: true, seed: 31, win: '#35505f'});
  return h('group', null,
    h(Terrain, {P}),
    h(PaintedBlock, {size: [9, 4.2, 5], pos: [0, y + 2.1, 0], color: wall, map}),
    h(Block, {size: [9.6, 0.3, 1.3], pos: [0, y + 0.15, 3.1], color: '#8a6a48'}),
    h(PaintedBlock, {size: [2.6, 6.6, 2.6], pos: [-3.4, y + 3.3, 0.2], color: wall, map: facadeTex({wall, cols: 2, rows: 3, door: false, seed: 32})}),
    h(Pyramid, {w: 3.1, hgt: 2.2, pos: [-3.4, y + 6.6, 0.2], color: '#6a4a4a'}),
    h('group', {rotation: [0, Math.PI / 2, 0], position: [1.6, y + 4.2, 0]}, h(Roof, {w: 5.6, d: 8.2, hgt: 1.8, color: '#7a4a3a'})),
    h(Block, {size: [0.8, 2.2, 0.8], pos: [3.2, y + 5.6, -0.8], color: '#a9643f'}),
    h(Board, {t, appearAt: 19.3, size: [6.2, 1.2], pos: [1.2, y + 5.9, 2.7], lines: ['WASHINGTON HOTEL'], bg: '#efe3c8', fg: INK, fontSize: 56}),
    h(Character, {pos: [-1.8, y, 5.2], frame, pal: 'red', hat: 'tophat', folded: true, seed: 8}));
}

// ---------- 6. owners pay ----------
export function WorldOwners({t, frame}) {
  const x0 = X.owners, tb = wordTime('s6', 8);
  const k = clamp((t - tb) / 0.4);
  return h('group', null,
    h(Block, {size: [16, 0.4, 11], pos: [x0, -0.2, 0], color: '#9a7a58'}),
    h(Block, {size: [16, 8.5, 0.5], pos: [x0, 4.05, -4.8], color: '#cdbf9f'}),
    h(Block, {size: [0.5, 8.5, 11], pos: [x0 - 8, 4.05, 0], color: '#c4b48f'}),
    h(Board, {t, appearAt: 28.3, size: [7, 2.1], pos: [x0 + 0.5, 5.3, -4.4], lines: ['PROPERTY OWNERS', 'PAY THE COST'], bg: '#efe3c8', fg: INK, fontSize: 70}),
    h(Block, {size: [8.4, 1.7, 1.2], pos: [x0 + 0.3, 0.85, 0.5], color: '#7a5a3c'}),
    h(Character, {pos: [x0 - 2.2, 0, -1], frame, pal: 'navy', hat: 'bowler', seed: 1, phase: 0}),
    h(Character, {pos: [x0 + 0.1, 0, -1.1], frame, pal: 'green', hat: 'cap', glasses: true, seed: 4, phase: 1}),
    h(Character, {pos: [x0 + 2.4, 0, -1], frame, pal: 'red', hat: 'none', seed: 9, phase: 2, tie: '#35506a'}),
    k > 0.01 ? h('group', {position: [x0 + 1.3, 1.74, 0.6], rotation: [-Math.PI / 2.2, 0, 0], scale: [k, k, k]},
      h('mesh', {geometry: planeGeo(1.9, 1.3), material: basicMat(signTex(['THE BILL'], '#fbf6ea', '#a63a35', {size: 70}))})) : null);
}

// ---------- 7. timber cribbing ----------
export function WorldCribs({t, frame}) {
  const x0 = X.cribs;
  const yb = 0.8 + 6.7 * (1 - ease((t - 35.6) / 3.9));
  const n = Math.max(0, Math.floor((yb - 0.8) / 0.5));
  const P = {cx: 0, cz: -32, H: 10, sig: 12, cut: 0, bay: false};
  const stacks = [];
  [[-2.4, -1.6], [2.4, -1.6], [-2.4, 1.6], [2.4, 1.6]].forEach(([sx, sz], si) => {
    for (let i = 0; i < n; i++) {
      const along = i % 2 === 0;
      stacks.push(h(Block, {key: si + '-' + i, size: along ? [1.5, 0.46, 0.34] : [0.34, 0.46, 1.5], pos: [sx, 0.8 + 0.25 + i * 0.5, sz], color: i % 3 === 0 ? '#b98a52' : '#a87a46', t: 0.08}));
    }
  });
  const rings = [];
  for (let i = 0; i < n; i += 1) rings.push(h(Cyl, {key: 'r' + i, r: 0.3, len: 0.12, pos: [0, 0.86 + i * 0.5, 0], color: '#4a4a52', seg: 8, t: 0.06}));
  const wall = '#b4694f';
  const map = facadeTex({wall, cols: 3, rows: 3, door: true, seed: 44, brick: true, win: '#2f4452'});
  return h('group', null,
    h(Terrain, {P}),
    h(Block, {size: [60, 0.3, 36], pos: [x0, -0.1, 8], color: '#b9a98a', ink: false}),
    h(Block, {size: [6.8, 0.8, 5.8], pos: [x0, 0.4, 0], color: '#8a4a3a'}),
    h('group', {position: [x0, 0, 0]}, stacks, h('group', {position: [0, 0, 0]}, rings, h(Cyl, {r: 0.12, len: Math.max(0.1, yb - 0.8), pos: [0, 0.8 + Math.max(0.1, yb - 0.8) / 2, 0], color: '#3d3a3a', seg: 8}))),
    h('group', {position: [x0, yb, 0]},
      h(PaintedBlock, {size: [6, 7, 5], pos: [0, 3.5, 0], color: wall, map}),
      h(Block, {size: [6.5, 0.6, 5.5], pos: [0, 7.2, 0], color: '#d8c9a6'}),
      h(Block, {size: [0.9, 1.6, 0.9], pos: [1.8, 8.1, -1], color: '#8a4a3a'})),
    h(Board, {t, appearAt: wordTime('s7b', 8), size: [3, 1.3], pos: [x0 - 5.6, 2.2, 3.6], rot: [0, 0.35, 0], lines: ['NEW', 'FOUNDATION'], bg: '#efe3c8', fg: INK, poles: 1.4, fontSize: 56}),
    h(Character, {pos: [x0 - 4.6, 0, 4.4], frame, pal: 'gray', hat: 'cap', seed: 6, hgt: 3.2, phase: 1}),
    h(Character, {pos: [x0 + 4.9, 0, 4.6], frame, pal: 'brown', hat: 'cap', glasses: true, seed: 7, hgt: 3.2, phase: 2}));
}

// ---------- 8. Blanchard trench ----------
export function WorldBlanchard({t, frame}) {
  const x0 = X.blanchard;
  const P = {cx: 0, cz: 0, H: 11, sig: 1, cut: 0, trench: true, bay: false};
  const f = -Math.PI / 2;
  return h('group', null,
    h(Terrain, {P, pos: [x0, 0, 0]}),
    h(Block, {size: [60, 0.1, 5.2], pos: [x0, 1.22, 0], color: '#8d7b6a', ink: false}),
    h('group', {position: [x0 - 4, 1.2, 2.3], rotation: [0, f, 0]},
      h(Cyl, {r: 0.13, len: 4.6, pos: [0, 2.3, 0], color: '#3d3a3a', seg: 8}),
      h(Board, {size: [2.2, 0.55], pos: [0, 4.2, 0.2], lines: ['4TH AVE'], bg: '#2f5d4a', fg: '#f3e6c8', fontSize: 70}),
      h(Board, {size: [2.8, 0.55], pos: [0, 3.5, 0.2], rot: [0, 0.01, 0], lines: ['BLANCHARD ST'], bg: '#2f5d4a', fg: '#f3e6c8', fontSize: 52})),
    h(Board, {t, appearAt: 43.5, size: [5, 2], pos: [x0 + 3.5, 1.2 + 5.2 + 1, -1.2], rot: [0, f, 0], lines: ['CUT DOWN', 'OVER 100 FT'], bg: '#efe3c8', fg: '#a63a35', poles: 5.2, fontSize: 64}),
    h(Character, {pos: [x0 + 0.5, 1.22, 1.2], frame, pal: 'navy', hat: 'bowler', seed: 12}));
}

// ---------- 9/10. the flat city ----------
export function WorldCity({t, frame}) {
  const x0 = X.city;
  const P = {...HILL, cut: 1};
  const sizes = [[5, 6], [4, 8], [6, 5], [4.6, 7], [5.2, 9], [4, 6], [6, 7.5], [4.4, 5.5], [5, 8]];
  const b = [];
  let xx = x0 - 24;
  sizes.forEach(([w, hh], i) => {
    const wall = WALLS[i % WALLS.length];
    b.push(h(PaintedBlock, {key: i, size: [w, hh, 5], pos: [xx + w / 2, 1.2 + hh / 2, -8], color: wall, map: facadeTex({wall, cols: Math.max(2, Math.round(w / 1.7)), rows: Math.round(hh / 1.8), door: true, seed: 60 + i, brick: i % 2 === 1})}));
    b.push(h(Block, {key: 'c' + i, size: [w + 0.4, 0.45, 5.4], pos: [xx + w / 2, 1.2 + hh + 0.2, -8], color: '#d8c9a6'}));
    xx += w + 0.6;
  });
  return h('group', null,
    h(Terrain, {P, pos: [x0, 0, 0]}),
    h(Block, {size: [80, 0.12, 4.6], pos: [x0, 1.26, 0], color: '#8d7b6a', ink: false}),
    h(Block, {size: [80, 0.22, 1.4], pos: [x0, 1.3, 3.4], color: '#cdbf9f', ink: false}),
    h(Block, {size: [80, 0.22, 1.4], pos: [x0, 1.3, -3.4], color: '#cdbf9f', ink: false}),
    b,
    h(LampPost, {pos: [x0 - 12, 1.4, 4.1]}),
    h(LampPost, {pos: [x0 + 12, 1.4, 4.1]}),
    h(Board, {t, appearAt: wordTime('s9', 8), size: [10, 1.7], pos: [x0, 1.2 + 5.8 + 0.85, 1.0], lines: ['DENNY REGRADE'], bg: '#efe3c8', fg: INK, poles: 5.8, fontSize: 100}),
    h(Character, {pos: [x0 - 9, 1.3, 4.6], frame, pal: 'navy', hat: 'bowler', seed: 15, phase: 0}),
    h(Character, {pos: [x0 + 7, 1.3, 4.4], frame, pal: 'green', hat: 'none', glasses: true, seed: 16, phase: 3}));
}
