import {useMemo} from 'react';
import * as THREE from 'three';
import {h, lerp, smooth, clamp, toon} from './kit.js';

// height of the ground at local (x,z). P = {cx,cz,H,sig,cut,pillar,trench,bay}
export function heightAt(x, z, P) {
  const dx = x - P.cx, dz = z - P.cz;
  let base;
  if (P.trench) {
    const c = smooth(7.5, 3.5, Math.abs(dz));
    base = lerp(P.H, 1.2, c);
  } else {
    base = P.H * Math.exp(-(dx * dx + dz * dz) / (2 * P.sig * P.sig));
  }
  if (P.bay) {
    const s = clamp((-z - 24) / 14);
    base = base * (1 - s) - 5 * s;
  }
  let hh = base;
  if (P.cut > 0) hh = lerp(base, Math.min(base, 1.2), P.cut);
  if (P.pillar) {
    const pd = Math.hypot(x - P.pillar.x, z - P.pillar.z);
    const m = smooth(P.pillar.r1, P.pillar.r0, pd);
    hh = lerp(hh, base, m);
  }
  return hh;
}

const grass = new THREE.Color('#93b86c'), clay = new THREE.Color('#c4915e'), sand = new THREE.Color('#d9c48f'), street = new THREE.Color('#b9a98a');

export function Terrain({pos = [0, 0, 0], P, size = 120, seg = 96}) {
  const key = Math.round((P.cut || 0) * 80);
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(size, size, seg, seg);
    g.rotateX(-Math.PI / 2);
    const p = g.attributes.position;
    const col = new Float32Array(p.count * 3);
    const Q = {...P, cut: 0};
    const c = new THREE.Color();
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), z = p.getZ(i);
      const y = heightAt(x, z, P);
      const y0 = heightAt(x, z, Q);
      p.setY(i, y);
      if (y < 0.1) c.copy(sand);
      else if (y0 - y > 0.8) c.copy(clay);
      else if (P.cut > 0.9 || P.trench && y < 1.5) c.copy(street);
      else c.copy(grass);
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.computeVertexNormals();
    return g;
  }, [key, P.cx, P.cz, P.H, P.sig, !!P.trench, !!P.bay, P.pillar && P.pillar.x]);
  return h('group', {position: pos},
    h('mesh', {geometry: geo, material: toon('#ffffff', {vertexColors: true}), receiveShadow: true}),
    P.bay ? h('mesh', {position: [0, 0, 0], rotation: [-Math.PI / 2, 0, 0], material: toon('#7fb8c8'), geometry: waterGeo()}) : null);
}
let _w = null;
function waterGeo() {
  if (!_w) _w = new THREE.PlaneGeometry(240, 240);
  return _w;
}
