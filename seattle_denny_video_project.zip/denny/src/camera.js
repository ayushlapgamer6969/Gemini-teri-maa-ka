// monotone cubic time warp: T = beat times per path key; returns path position 0..1
export function warpU(T, t) {
  const n = T.length;
  if (t <= T[0]) return 0;
  if (t >= T[n - 1]) return 1;
  const sec = [];
  for (let i = 0; i < n - 1; i++) sec.push(1 / (n - 1) / (T[i + 1] - T[i]));
  const m = [0];
  for (let i = 1; i < n - 1; i++) m.push((2 * sec[i - 1] * sec[i]) / (sec[i - 1] + sec[i]));
  m.push(0);
  let i = 0;
  while (t > T[i + 1]) i++;
  const hh = T[i + 1] - T[i], x = (t - T[i]) / hh, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * hh * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * hh * m[i + 1];
}
const L = (a, b, f) => [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
// keys: [{at, p:[x,y,z], l:[x,y,z]}]
export function camAt(keys, t) {
  const T = keys.map((k) => k.at);
  const u = warpU(T, t);
  const n = keys.length;
  const s = Math.min(Math.max(u, 0), 1) * (n - 1);
  const i = Math.min(n - 2, Math.floor(s));
  const f = s - i;
  return {p: L(keys[i].p, keys[i + 1].p, f), l: L(keys[i].l, keys[i + 1].l, f)};
}
