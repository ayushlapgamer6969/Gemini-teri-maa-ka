import React from 'react';
import * as THREE from 'three';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {h, clamp, skyTex, basicMat} from './kit.js';
import {FPS, DIPS, X, shotIndex} from './times.js';
import {KEYS, LOC} from './plan.js';
import {camAt} from './camera.js';
import {WorldHill, WorldOffice, WorldCut, WorldHotel, WorldOwners, WorldCribs, WorldBlanchard, WorldCity} from './worlds.js';

const WORLD = {hill: WorldHill, office: WorldOffice, cut: WorldCut, hotel: WorldHotel, owners: WorldOwners, cribs: WorldCribs, blanchard: WorldBlanchard, city: WorldCity};
const LIGHT_X = {hill: 0, office: X.office, cut: X.cut, hotel: X.hotel, owners: X.owners, cribs: X.cribs, blanchard: X.blanchard, city: X.city};
const LIGHT_Y = {hill: 6, office: 2, cut: 5, hotel: 10, owners: 2, cribs: 3, blanchard: 3, city: 3};
const INDOOR = {office: true, owners: true};
const CREAM = '#f3e6c8';
let _sky = null;

function Scene({t, frame, si}) {
  const camera = useThree((s) => s.camera);
  const scene = useThree((s) => s.scene);
  const loc = LOC[si];
  const c = camAt(KEYS[si], t);
  camera.position.set(c.p[0], c.p[1], c.p[2]);
  camera.lookAt(c.l[0], c.l[1], c.l[2]);
  const bg = INDOOR[loc] ? '#e6d8b4' : '#e9dcc0';
  scene.background = new THREE.Color(bg);
  scene.fog = INDOOR[loc] ? null : new THREE.Fog(bg, 90, 260);
  const lx = LIGHT_X[loc];
  const World = WORLD[loc];
  _sky = _sky || new THREE.SphereGeometry(300, 24, 16);
  const skyMat = basicMat(skyTex());
  skyMat.side = THREE.BackSide;
  skyMat.fog = false;
  skyMat.depthWrite = false;
  return h(React.Fragment, null,
    h('mesh', {geometry: _sky, material: skyMat, position: [c.p[0], c.p[1], c.p[2]], renderOrder: -10}),
    h('hemisphereLight', {args: ['#ffffff', '#b79b78', 1.15]}),
    h('directionalLight', {
      ref: (l) => { if (l) { l.target.position.set(lx, LIGHT_Y[loc], 0); l.target.updateMatrixWorld(); } },
      position: [lx - 24, 42, 30], intensity: 2.3, color: '#fff0d0', castShadow: true,
      'shadow-mapSize': [2048, 2048], 'shadow-camera-left': -40, 'shadow-camera-right': 40, 'shadow-camera-top': 40, 'shadow-camera-bottom': -40,
      'shadow-camera-near': 1, 'shadow-camera-far': 140, 'shadow-bias': -0.0006,
    }),
    h(World, {t, frame}));
}

export const Full = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const t = frame / FPS;
  const si = shotIndex(t);
  let dip = 0;
  DIPS.forEach((d) => { dip = Math.max(dip, clamp(1 - Math.abs(t - d) / 0.2)); });
  return h(AbsoluteFill, {style: {background: CREAM}},
    h(ThreeCanvas, {width, height, shadows: true, flat: true, camera: {fov: 80, near: 0.1, far: 600, position: [0, 5, 20]}},
      h(Scene, {t, frame, si})),
    h(AbsoluteFill, {style: {background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(53,31,34,0.28) 100%)', pointerEvents: 'none'}}),
    h(AbsoluteFill, {style: {background: CREAM, opacity: dip, pointerEvents: 'none'}}));
};
