# Camera plan (real voice-over timing, 54.75 s, 30 fps, 720x1280)
| Shot | Time | Place | Camera path | Foreground / midground / background | In-world labels |
|---|---|---|---|---|---|
| 1 | 0.0-5.4 | Hill overview | crane down and push: (-22,30,52) -> (-6,17,34) | board / hill with houses / bay and downtown | "DENNY HILL" board |
| 2 | 5.4-11.6 | Engineer's office | push in, then to the map (reached on "city engineer") | desk / engineer / map wall | "62 BLOCKS" stamp, "CITY ENGINEER" nameplate, map "DENNY HILL" |
| 3 | 11.6-17.65 | Hydraulic cut | sideways track left to right | giant / jets and worker / melting hill | "HYDRAULIC GIANTS" board |
| 4 | 17.65-22.0 | Hotel on the summit | push in | owner / hotel / hill and bay | "WASHINGTON HOTEL" board |
| 5 | 22.0-27.95 | Same hill being cut | crane down to street level, looking up | pillar / hotel / bay | none |
| 6 | 27.95-31.8 | Owners' office | sideways track left to right | counter / three owners / back wall | "PROPERTY OWNERS PAY THE COST", "THE BILL" |
| 7 | 31.8-40.0 | Cribbing yard | wide -> stacks (on "timber stacks") -> lowering -> rest | cribs and worker / apartment house / mound | "NEW FOUNDATION" board |
| 8 | 40.0-44.3 | Blanchard trench | drop from above into the street, look down it | street sign / board / earth walls | "4TH AVE", "BLANCHARD ST", "CUT DOWN OVER 100 FT" |
| 9 | 44.3-50.5 | Flat city | sideways track along the street | lamp / pedestrians / buildings | "DENNY REGRADE" banner on two poles |
| 10 | 50.5-54.75 | Flat city | pull back and up to the bay, ends at rest | street / city / bay | none |

Cuts: 0.4 s dip to cream at every change of place (5.4, 11.6, 17.65, 27.95, 31.8, 40.0, 44.3). Shots 5 and 10 continue the previous place.
