@echo off
cd /d "%~dp0"
echo === Test render: only 30 frames (first second) ===
where node >nul 2>nul || (echo Node.js is not installed. Install the LTS version from nodejs.org, then double-click this file again. & pause & exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed. Check your internet and try again. & pause & exit /b 1)
if not exist out mkdir out
call npx remotion render src/index.js Denny out\test.mp4 --frames=0-29 --gl=angle --concurrency=4 --image-format=jpeg --jpeg-quality=92 --crf=17
echo.
echo If out\test.mp4 opened fine, run render.bat next.
pause
